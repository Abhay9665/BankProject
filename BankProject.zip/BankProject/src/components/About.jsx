import React from 'react'
import Footer from './Footer';
import Nav from './Nav';
const About = () => {
  return (
    <div><Nav/>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum, tenetur reprehenderit saepe non commodi eligendi nam. Dolore sed corporis ratione blanditiis fuga minima, veniam mollitia delectus, itaque rerum odio nihil impedit similique dolorem officiis, facere expedita eum aliquam porro atque commodi. Quam nobis repellendus iure impedit vero. Necessitatibus temporibus veritatis quibusdam dolore nulla eligendi quasi? Ipsa, vel. Blanditiis maxime temporibus quod perspiciatis non quos atque impedit maiores enim. Pariatur expedita labore id illum asperiores perferendis ipsa rem quos doloribus incidunt illo, debitis tempore! Adipisci corrupti nihil explicabo corporis rerum earum suscipit. Eaque quisquam voluptate perspiciatis ullam! Dolore accusamus sapiente omnis.


    
    
    </div>
  )
}

export default About