import React from 'react'
import Footer from './Footer';
import Nav from './Nav';
const Service = () => {
  return (
    <div><Nav/>
    <h1>Services Our Bank</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, eveniet animi vel sit inventore doloribus nostrum eos molestias officia odit iusto, quasi voluptatem incidunt in nemo voluptatum alias corrupti maiores adipisci magni aperiam omnis dolorem ex illo? Amet cupiditate, neque sequi fuga nobis eveniet praesentium reiciendis soluta impedit eius ab! Beatae recusandae non, libero deserunt alias nostrum tempora unde tempore nam quidem debitis quis neque in ea expedita iste, est maxime possimus cupiditate assumenda ipsam. Possimus vel numquam odit enim consequuntur obcaecati. Exercitationem atque, at odio est commodi tempore, ut optio harum aspernatur sunt cum ipsam, officia nemo saepe. Doloribus sunt asperiores impedit explicabo, minus ratione, quos rerum blanditiis enim fuga eveniet mollitia minima reiciendis labore eligendi. Voluptatum est in inventore, excepturi rem hic repellat dolorum nulla quis placeat quas enim magni doloribus illo quod at labore accusantium reiciendis accusamus temporibus veritatis sequi similique maxime saepe. Est accusantium recusandae iusto consequuntur reprehenderit doloremque adipisci quod illum, fuga magni voluptates animi, culpa ea. Placeat omnis quisquam vitae voluptatum veniam. Quaerat voluptates error sapiente inventore eos soluta maiores exercitationem saepe alias aut quis eveniet corrupti vero voluptatem eaque, repellendus doloremque placeat! Quam porro quis architecto expedita facilis sequi voluptatibus veniam nesciunt neque?</p>

   
    
    </div>
  )
}

export default Service